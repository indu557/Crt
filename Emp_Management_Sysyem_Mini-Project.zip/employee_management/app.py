from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Necessary for session management

def create_connection():
    return sqlite3.connect('employees.db')

def create_tables():
    connection = create_connection()
    with connection:
        connection.execute("""
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            age INTEGER,
            department TEXT,
            salary REAL
        );
        """)
        connection.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        );
        """)
    connection.close()

@app.route('/')
def home():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        connection = create_connection()
        user = connection.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        connection.close()

        if user and check_password_hash(user[2], password):
            session['logged_in'] = True
            return redirect(url_for('home'))
        else:
            return render_template('login.html', error='Invalid credentials')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        hashed_password = generate_password_hash(password, method='sha256')

        connection = create_connection()
        try:
            connection.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
            connection.commit()
            connection.close()
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            connection.close()
            return render_template('register.html', error='Username already exists')
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

@app.route('/add', methods=['GET', 'POST'])
def add_employee():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        department = request.form['department']
        salary = request.form['salary']

        connection = create_connection()
        connection.execute("INSERT INTO employees (name, age, department, salary) VALUES (?, ?, ?, ?)", (name, age, department, salary))
        connection.commit()
        connection.close()

        return redirect(url_for('view_employees'))
    return render_template('add_employee.html')

@app.route('/view')
def view_employees():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    connection = create_connection()
    employees = connection.execute("SELECT * FROM employees").fetchall()
    connection.close()
    return render_template('view_employees.html', employees=employees)

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_employee(id):
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    connection = create_connection()
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        department = request.form['department']
        salary = request.form['salary']

        connection.execute("UPDATE employees SET name = ?, age = ?, department = ?, salary = ? WHERE id = ?", (name, age, department, salary, id))
        connection.commit()
        connection.close()

        return redirect(url_for('view_employees'))

    employee = connection.execute("SELECT * FROM employees WHERE id = ?", (id,)).fetchone()
    connection.close()
    return render_template('edit_employee.html', employee=employee)

@app.route('/delete/<int:id>', methods=['POST'])
def delete_employee(id):
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    connection = create_connection()
    connection.execute("DELETE FROM employees WHERE id = ?", (id,))
    connection.commit()
    connection.close()
    return redirect(url_for('view_employees'))

if __name__ == "__main__":
    create_tables()
    app.run(debug=True)
